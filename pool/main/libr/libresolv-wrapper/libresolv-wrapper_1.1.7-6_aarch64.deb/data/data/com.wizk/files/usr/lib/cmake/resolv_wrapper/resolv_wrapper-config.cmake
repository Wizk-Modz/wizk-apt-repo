set(RESOLV_WRAPPER_LIBRARY /data/data/com.wizk/files/usr/lib/libresolv_wrapper.so)
