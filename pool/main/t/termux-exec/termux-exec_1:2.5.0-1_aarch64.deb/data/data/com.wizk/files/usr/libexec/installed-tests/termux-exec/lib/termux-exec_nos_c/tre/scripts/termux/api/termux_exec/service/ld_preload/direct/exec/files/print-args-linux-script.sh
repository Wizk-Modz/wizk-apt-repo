#!/data/data/com.wizk/files/usr/bin/sh

echo "$@"
